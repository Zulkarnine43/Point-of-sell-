<?php $__env->startSection('body'); ?>
    <style>
        .si{
            font-size: 20px;
            font-weight: bold;
            letter-spacing: 1.4px;
            line-height: 40px;
            text-indent: 0px;
            alignment: left;
            text-align: left;
        }
        .co{
            color: White;
            background-color: black;
            font-style: italic;
            text-align: center;
        }
    </style>

    <div class="login" style="margin-top: 100px; margin-bottom: 100px">
        <h3  class="offset-4 col-md-3 text-center text-success">Product Export</h3>
    </div>


    <form class="offset-3" method="POST" action="<?php echo e(route('add_cart')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>



          <div class="form-group col-md-offset-3 col-md-6">
              <label class="si co">product Name</label>
              <select class="form-control" name="product_name" required>
                  <option>---Select a Name</option>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($product->product_name); ?>"><?php echo e($product->product_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>


        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product price</label>
            <input type="number" name="product_price" class="form-control" min="1" placeholder="product price" required>
        </div>

        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product Quantity</label>
            <input type="number" name="product_quantity" class="form-control" min="1" placeholder="product Quantity" required>
        </div>



       <!-- <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">Total price</label>
            <input type="text" name="total_price" class="form-control" placeholder="Short Discreption" required>
        </div>-->

        <div class="form-group">
            <div class="col-md-offset-5  col-md-12 ">
                <input class="btn-success" type="submit" name="btn" value="Save product Info" >
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>