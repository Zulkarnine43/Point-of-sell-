
<link href="<?php echo e(url('public/css/manage.css')); ?>" rel="stylesheet" type="text/css">
    <div class="table-responsive">
        <h3 class="text text-success text-center">Product</h3>
        <table border="1px" >

            <tr class="" style="color: white ; background-color: black">
                <th scope="col" >product-name</th>
                <th scope="col">product-quantity</th>
                <th scope="col">product-price</th>
                <th>total price</th>

            </tr>
            <?php ($sum=0); ?>;
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="t2">
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->qty); ?></td>
                <td><?php echo e($product->price); ?></td>
                <?php ($sum =$sum+$product->price*$product->qty); ?>
                <td><?php echo e($sum); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>
