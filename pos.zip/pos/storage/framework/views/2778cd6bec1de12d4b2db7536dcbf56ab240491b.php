<?php $__env->startSection('body'); ?>
    <link href="<?php echo e(url('public/css/manage.css')); ?>" rel="stylesheet" type="text/css">
    <div class="checkout">
        <div class="container">
            <h3>My Shopping Bag</h3>
            <div class="table-responsive checkout-right animated wow slideInUp" data-wow-delay=".5s">
                <table class="timetable_sub table-bordered">
                    <thead>
                    <tr class="t1">
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total Price</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <?php ($sum=0); ?>;
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="rem1 t2">
                            <td class="invert"><?php echo e($product->name); ?></td>
                            <td class="invert"><?php echo e($product->qty); ?></td>
                            <td class="invert"><?php echo e($product->price); ?></td>
                            <td class="invert" id="invert2">Tk.<?php echo e($product->price*$product->qty); ?></td>
                            <?php ($sum =$sum+$product->price*$product->qty); ?>
                            <td>
                                <span><a href="<?php echo e(route('cart_delete',['id'=>$product->rowId])); ?>"> delete</a></span>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
            <div class="checkout-left">

                <div class="checkout-right-basket animated wow slideInRight" data-wow-delay=".5s">
                    <p>
                        <a href="<?php echo e(route('shipping_add')); ?>" class="btn btn-info btn-lg offset-3">
                            <span class="glyphicon"></span> More Export
                        </a>

                        <a href="<?php echo e(route('order_delete')); ?>" class="btn btn-info btn-lg">
                            <span class="glyphicon"></span> Delete order
                        </a>

                        <a href="<?php echo e(route('order_delete')); ?>" class="btn btn-info btn-lg">
                            <span class="glyphicon"></span> New order
                        </a>
                    </p>
                </div>
                <div class="checkout-left-basket animated wow slideInLeft" data-wow-delay=".5s">
                    <h4>Shopping basket</h4>
                    <table class="table-bordered" >
                        <tr class="t1">
                        <td>Taka<i>-</i> <span>Tk.<?php echo e($sum); ?></span></td>
                        <td>Vat <i>-</i> <span>Tk 0.0</span></td>
                        <td >Total<i>-</i> <span  id="tot"><?php echo e($sum); ?></span></td>
                        </tr>
                    </table>
                    <a href="<?php echo e(route('downloadInfo')); ?>" class="btn btn-info btn-lg offset-5">
                        <span class="glyphicon"></span>Download Invoice
                    </a>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>