<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[
    'uses' =>'adminController@register',
    'as' =>'register'
]);

Route::post('/register/save',[
    'uses' => 'adminController@register_save',
    'as' => 'register_save'
]);

Route::get('/admin/login',[
    'uses' =>'adminController@admin_login',
    'as' =>'admin_login'
]);

Route::post('/admin/login/check',[
    'uses' =>'adminController@admin_login_check',
    'as' =>'admin_login_check'
]);

Route::get('/admin/page',[
    'uses' =>'adminController@admin',
    'as' =>'admin'
]);

Route::get('/product/add',[
    'uses' =>'productController@product_add',
    'as' =>'product_add'
]);

Route::post('/product/add/save',[
    'uses' =>'productController@product_add_save',
    'as' =>'product_add_save'
]);

Route::get('/product/manage',[
    'uses' =>'productController@product_manage',
    'as' =>'product_manage'
]);

Route::get('/shipping/add',[
    'uses' =>'shippingController@shipping_add',
    'as' =>'shipping_add'
]);


Route::post('/add/cart',[
    'uses' =>'shippingController@add_cart',
    'as' =>'add_cart'
]);

Route::get('/cart/delete/{id}',[
    'uses' =>'shippingController@cart_delete',
    'as' =>'cart_delete'
]);
Route::get('/download/Info',[
    'uses' =>'shippingController@downloadInfo',
    'as' =>'downloadInfo'
]);

Route::get('/order/delete',[
    'uses' =>'shippingController@order_delete',
    'as' =>'order_delete'
]);

Route::get('/shipping/manage',[
    'uses' =>'shippingController@shipping_manage',
    'as' =>'shipping_manage'
]);
