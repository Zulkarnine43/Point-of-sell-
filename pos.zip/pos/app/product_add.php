<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_add extends Model
{
    //
    protected $fillable=['code','product_name','product_price','product_quantity','product_description','product_image'];
}
