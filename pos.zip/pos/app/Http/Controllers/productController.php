<?php

namespace App\Http\Controllers;

use App\product_add;
use Illuminate\Http\Request;

class productController extends Controller
{
    //
    public function product_add(){
        return view('product.product_add');
    }

    public function product_add_save(Request $request){
        $addProducts = new product_add();

        $productImage = $request->file('product_image');
        if ($productImage) {
            $imageName = $productImage->getClientOriginalName();
            $directory = 'product_images/';
            $imageUrl = $directory.$imageName;
            $productImage->move($directory, $imageName);
        }
        $addProducts->code = $request->code;
        $addProducts->product_name = $request->product_name;
        $addProducts->product_price = $request->product_price;
        $addProducts->product_quantity = $request->product_quantity;
        $addProducts->product_description = $request->product_description;
        $addProducts->product_image = $imageUrl;
        $addProducts->save();

        return redirect('/product/add')->with('message', 'Save Products Info Successfully');

    }

    public function product_manage(){
        $products=product_add::all();
        return view('product.product_manage',['products'=>$products]);
    }
}
