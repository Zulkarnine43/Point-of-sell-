<?php

namespace App\Http\Controllers;

use App\product_add;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use PDF;

class shippingController extends Controller
{
    //

    public function shipping_add(){
       $products= product_add::all();
        return view('shipping.shipping_add',['products'=>$products]);
    }


    public function add_cart(Request $request){
        Cart::add([
            'name'=>$request->product_name,
            'qty'=>$request->product_quantity,
            'price'=>$request->product_price,
            'id'=>$request->product_quantity*$request->product_price
        ]);
         return redirect('/shipping/add');
    }

    public function cart_delete($id){
        Cart::remove($id);
        return redirect('/shipping/manage');
    }

    public function shipping_manage(){
        $allCart=Cart::content();
        return view('shipping.shipping_manage',['products'=>$allCart]);
    }

    public function downloadInfo(){
        $allCart=Cart::content();
        $pdf = PDF::loadView('shipping.download_invoice',['products'=>$allCart]);
        return $pdf->stream('invoice.pdf');
    }

    public function order_delete(){
        Cart::destroy();
        $products= product_add::all();
        return view('shipping.shipping_add',['products'=>$products]);
    }
}
