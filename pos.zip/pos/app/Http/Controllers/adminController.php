<?php

namespace App\Http\Controllers;

use App\admin_register;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

class adminController extends Controller
{
    //

    public function register(){
        return view('admin.register');
    }
    public function register_save(Request $request){
        $this->validate($request,['email'=>'required|email|max:255|unique:users'],[
            'email.required'=>'Email cannot be empty','email'=>'Email format is not valid.'
        ]);
        $this->validate($request,[
            'username'=>'required|string|max:255',
            'password'=>[
                'required',
                'string',
                'min:6',             // must be at least 6 characters in length
                'regex:/[a-z]/',      // must contain at least one lowercase letter
                'regex:/[A-Z]/',      // must contain at least one uppercase letter
                'regex:/[0-9]/',      // must contain at least one digit
            ],
            'confirm_password' =>'required|same:password'
        ]);
        $regis = new admin_register();
        $regis->username = $request->username;
        $regis->email = $request->email;
        $regis->password =encrypt( $request->password);
        $regis->confirm_password =encrypt($request->confirm_password);
        $regis->save();

      /*  $data=$request->toArray();
        Mail::send('admin.verification_mail',$data,function($message) use ($data){
            $message->to($data['email']);
            $message->subject('verification_mail');
        });*/

        return redirect('/')->with('verify','Please Verify Your Email Account');

    }

    public function admin_login(){
        return view('admin.admin_login');
    }

    public function admin_login_check(Request $request){
        $password=encrypt( $request->password);

        $admin = admin_register::where('email',$request->email )->first();
        $admin2= admin_register::where('password',$password)->get();

        if($admin && $admin2){
            Session::put('emaill', $admin->email);
            Session::put('name',$admin->username);
            return redirect('/admin/page');
        }
        else {
            return redirect('/admin/login')->with('message', 'required valid password');
        }
    }



    public function admin(){
        return view('admin.admin');
    }

}
