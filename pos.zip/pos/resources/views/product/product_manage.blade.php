
@extends('admin.headerFooter')
@section('body')

    <link href="{{url('public/css/manage.css')}}" rel="stylesheet" type="text/css">

    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage product Info</h3>
                    <table class="table table-bordered small text-center">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>code </th>
                            <th>product name </th>
                            <th>product price</th>
                            <th>product quantity</th>
                            <th>product description</th>
                            <th>product image</th>
                            <th>Creadted _at</th>
                            <th>Action</th>
                        </tr>
                        @php($i=1);
                        @foreach($products as $product)
                            <tr class="t2">
                                <td>{{$i++}}</td>
                                <td>{{$product->code}}</td>
                                <td>{{$product->product_name}}</td>
                                <td>{{$product->product_price}}</td>
                                <td>{{$product->product_quantity}}</td>
                                <td>{{$product->product_description}}</td>
                                <td>{{$product->product_image}}</td>
                                <td>{{$product->created_at}}</td>
                                <td>
                                    <a href="" class="btn-success ">Edit</a>
                                    <a href="" class="btn-success ">Delete</a>
                                </td>
                            </tr>
                        @endforeach

                    </table>
                </div>
            </div>
        </div>
    </div>


@endsection()
