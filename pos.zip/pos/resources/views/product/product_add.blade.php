@extends('admin.headerFooter')
@section('body')
    <script src="{{url('public/myhome/ckeditor/ckeditor.js')}}"></script>
    <script src="{{url('public/myhome/ckeditor/samples/js/sample.js')}}"></script>
    <link rel="stylesheet" href="{{url('public//myhome/ckeditor/samples/css/samples.css')}}">
    <link rel="stylesheet" href="{{url('public/myhome/ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css')}}">

    <style>
        .si{
            font-size: 20px;
            font-weight: bold;
            letter-spacing: 1.4px;
            line-height: 40px;
            text-indent: 0px;
            alignment: left;
            text-align: left;
        }
        .co{
            color: White;
            background-color: black;
            font-style: italic;
            text-align: center;
        }
    </style>

    <div class="login" style="margin-top: 100px; margin-bottom: 100px">
        <h3  class="offset-4 col-md-3 text-center text-success">Product Import</h3>
        <h4 class="offset-4 col-md-3 text-center text-success">{{Session::get('message')}}</h4>
    </div>


    <form class="offset-3" method="POST" action="{{route('product_add_save')}}" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group col-md-offset-3 col-md-6">
            <label  class="si co">product code</label>
            <input type="text" name="code" class="form-control" placeholder="product code" required>
        </div>

        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product Name</label>
            <input type="text" name="product_name" class="form-control" placeholder="product Name" required>
        </div>


        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product price</label>
            <input type="text" name="product_price" class="form-control" min="1" placeholder="product price" required>
        </div>

        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product Quantity</label>
            <input type="text" name="product_quantity" class="form-control" min="1" placeholder="product Quantity" required>
        </div>

        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product Description</label>
            <input type="text" name="product_description" class="form-control" placeholder="Short Discreption" required>
        </div>


        <div class="form-group col-md-offset-3 col-md-6">
            <label class="si co">product image-</label>
            <input type="file" name="product_image" accept="image/*" required>
        </div>

        <div class="form-group">
            <div class="col-md-offset-5  col-md-12 ">
                <input class="btn-success" type="submit" name="btn" value="Save product Info" >
            </div>
        </div>
    </form>

    <script>
        initSample();
    </script>
@endsection

