@extends('admin.headerFooter')
@section('body')
    <link href="{{url('public/css/manage.css')}}" rel="stylesheet" type="text/css">
    <div class="checkout">
        <div class="container">
            <h3>My Shopping Bag</h3>
            <div class="table-responsive checkout-right animated wow slideInUp" data-wow-delay=".5s">
                <table class="timetable_sub table-bordered">
                    <thead>
                    <tr class="t1">
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total Price</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    @php($sum=0);
                    @foreach($products as $product)
                        <tr class="rem1 t2">
                            <td class="invert">{{$product->name}}</td>
                            <td class="invert">{{$product->qty}}</td>
                            <td class="invert">{{$product->price}}</td>
                            <td class="invert" id="invert2">Tk.{{$product->price*$product->qty}}</td>
                            @php($sum =$sum+$product->price*$product->qty)
                            <td>
                                <span><a href="{{route('cart_delete',['id'=>$product->rowId])}}"> delete</a></span>
                            </td>
                        </tr>

                    @endforeach

                </table>
            </div>
            <div class="checkout-left">

                <div class="checkout-right-basket animated wow slideInRight" data-wow-delay=".5s">
                    <p>
                        <a href="{{route('shipping_add')}}" class="btn btn-info btn-lg offset-3">
                            <span class="glyphicon"></span> More Export
                        </a>

                        <a href="{{route('order_delete')}}" class="btn btn-info btn-lg">
                            <span class="glyphicon"></span> Delete order
                        </a>

                        <a href="{{route('order_delete')}}" class="btn btn-info btn-lg">
                            <span class="glyphicon"></span> New order
                        </a>
                    </p>
                </div>
                <div class="checkout-left-basket animated wow slideInLeft" data-wow-delay=".5s">
                    <h4>Shopping basket</h4>
                    <table class="table-bordered" >
                        <tr class="t1">
                        <td>Taka<i>-</i> <span>Tk.{{$sum}}</span></td>
                        <td>Vat <i>-</i> <span>Tk 0.0</span></td>
                        <td >Total<i>-</i> <span  id="tot">{{$sum}}</span></td>
                        </tr>
                    </table>
                    <a href="{{route('downloadInfo')}}" class="btn btn-info btn-lg offset-5">
                        <span class="glyphicon"></span>Download Invoice
                    </a>
                </div>
            </div>

        </div>
    </div>

@endsection
