
<link href="{{url('public/css/manage.css')}}" rel="stylesheet" type="text/css">
    <div class="table-responsive">
        <h3 class="text text-success text-center">Product</h3>
        <table border="1px" >

            <tr class="" style="color: white ; background-color: black">
                <th scope="col" >product-name</th>
                <th scope="col">product-quantity</th>
                <th scope="col">product-price</th>
                <th>total price</th>

            </tr>
            @php($sum=0);
            @foreach($products as $product)
            <tr class="t2">
                <td>{{$product->name}}</td>
                <td>{{$product->qty}}</td>
                <td>{{$product->price}}</td>
                @php($sum =$sum+$product->price*$product->qty)
                <td>{{$sum}}</td>

            </tr>
            @endforeach

        </table>
    </div>
